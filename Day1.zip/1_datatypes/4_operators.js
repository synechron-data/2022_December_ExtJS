"use strict"

// We cannot specify the type while declaring the variables
// Type of the variable will be implcitly defined(taken) at runtime
// We can provide(change) any value to any variable
// We can use any operator with any operand type

// var result1 = 10 * true;
// console.log(result1);

// var result2 = 10 * "abc";
// console.log(result2);

// console.log(true && "abc");
// console.log(false && "abc");

// // T && T = T
// // T && F = F

// console.log(true ? "abc" : "xyz");
// console.log(true && "abc" || "xyz");

// // var obj;
// // var obj = undefined;
// // var obj = null;
// var obj = { id: 1 };

// // if ((obj == null) || (obj == undefined))
// //     console.log("object is null or undefined");
// // else
// //     console.log("object is:", obj);

// if (!obj)
//     console.log("object is null or undefined");
// else
//     console.log("object is:", obj);

// -------------------------------------- Compare
// var a  = 10;
// var b = "10";

// console.log(typeof a);
// console.log(typeof b);

// console.log(a == b);            // Abstract Equality
// console.log(a === b);           // Strict Equality

var a = { id: 0 };
var b = { id: 0 };

console.log(a == b);            // Abstract Equality
console.log(a === b);           // Strict Equality

// Reference Copy
var c = b;
console.log(c == b);            // Abstract Equality
console.log(c === b);           // Strict Equality
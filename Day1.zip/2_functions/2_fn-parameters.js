"use strict"

// Function Creation
// function <FunctionName>(<Parameters>) {
//     <Function Body>
// }

// Function Call
// <FunctionName>(<Arguments>)

// function hello(person_name) {
//     console.log('Hello, ', person_name);
// }

// var r = hello();
// console.log(r);

// console.log(hello());

// hello("Manish");
// hello(10);
// hello(true);
// hello();
// hello("Synechron", "Pune");

// ----------------------------------------------- Handle Less number of Arguments & Type
// Function to add 2 numbers

// function add(x, y) {
//     // x = x || 0;
//     // y = y || 0;

//     if (x === void 0) x = 0;
//     if (y === void 0) y = 0;

//     if ((typeof x == "number") && (typeof y == "number"))
//         return x + y;

//     throw new TypeError("Invalid Arguments...");
// }

// console.log(add(2, 3));
// console.log(add(2));
// console.log(add());

// try {
//     console.log(add(2, "abc"));
// } catch (e) {
//     console.error(e.message);
// }

// --------------------------------------- Handle Extra number of Arguments
// function hello(person_name) {
//     console.log('Hello,', person_name);
//     console.log(arguments);
// }

// hello("Manish");
// hello("Manish", "Sharma");
// hello("Manish", "Sharma", "Pune");
// hello("Manish", "Sharma", "Pune", 411021);

// ------------------------------------ Variable Argument Functions
function average() {
    // console.log(arguments.length);
    var sum = 0;

    for (var i = 0; i < arguments.length; i++) {
        sum += arguments[i];
    }

    if (arguments.length)
        return sum / arguments.length;
    else
        return sum;
}

console.log(average());
console.log(average(1));
console.log(average(1, 2));
console.log(average(1, 2, 3, 4, 5));
console.log(average(1, 2, 3, 4, 5, 6, 7, 8, 9));
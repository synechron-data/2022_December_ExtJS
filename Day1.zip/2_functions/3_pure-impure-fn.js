// Create a function named append to add item into an array and return a new array
// Share the function privatly on chat window, once completed

// Impure Function
// function append(dataArr, item) {
//     dataArr[dataArr.length] = item;
//     return dataArr;
// }

// function append(dataArr, item) {
//     dataArr.push(item);
//     return dataArr;
// }

// // Pure Function
// function append(dataArr, item) {
//     var rArr = [].concat(dataArr);
//     rArr.push(item);
//     return rArr;
// }

// var arr = [10, 20];

// var newArr1 = append(arr, 100);
// console.log(newArr1);               // Expected: [10, 20, 100]

// var newArr2 = append(arr, 100);
// console.log(newArr2);               // Expected: [10, 20, 100]

// Assignment ---------------------------------------------------------------------------------------------
// Do not use builtin filter method

var employees = ["Akshay", "Basavaraj", "Bhavya", "Bibhu", "Chethan", "Chhavi"];

function filter(dataArr, x) {
    var newArr = [];

    for (var i = 0; i < dataArr.length; i++) {
        // if (dataArr[i][0] === x) {
        //     newArr.push(dataArr[i]);
        // }

        if (dataArr[i].charAt(0) === x) {
            newArr.push(dataArr[i]);
        }

        // if (dataArr[i].substring(0, 1) === x) {
        //     newArr.push(dataArr[i]);
        // }

        // var testString = "^" + x;
        // if (dataArr[i].match(testString)) {
        //     newArr.push(dataArr[i]);
        // }

        // ES 6 
        // if (dataArr[i].startsWith(x)) {
        //     newArr.push(dataArr[i]);
        // }
    }

    return newArr;
}

var result1 = filter(employees, 'A');
console.log(result1);                   // ["Akshay"];

var result2 = filter(employees, 'B');
console.log(result2);                   // ["Basavaraj", "Bhavya", "Bibhu"];

var result3 = filter(employees, 'C');
console.log(result3);                   // ["Chethan", "Chhavi"];

console.log(employees);                 // ["Akshay", "Basavaraj", "Bhavya", "Bibhu", "Chethan", "Chhavi"];
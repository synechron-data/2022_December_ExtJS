// function hello() {
//     console.log("Hello World!");
// }

// hello();

// // IIFE
// (function () {
//     console.log("Hello World 1!");
// })();

// (function () {
//     console.log("Hello World 2!");
// }());

// ------------------------------

function hello(name) {
    console.log("Hello", name);
}

hello("Manish");

// IIFE
(function (name) {
    console.log("Hello", name);
})("Abhijeet");

(function (name) {
    console.log("Hello", name);
}("Ramakant"));
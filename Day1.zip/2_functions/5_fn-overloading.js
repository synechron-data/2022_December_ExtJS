// function hello() {
//     console.log("Hello World!");
// }

// function hello(name) {
//     console.log("Hi,", name);
// }

// hello();
// hello("Manish");

// -------------------------------------

// function m1() {
//     console.log("Hello World!");
// }

// function m2(name) {
//     console.log("Hi,", name);
// }

// function hello() {
//     if (arguments.length === 0)
//         m1();
//     else if (arguments.length === 1)
//         m2(arguments[0]);
//     else
//         throw Error("Invalid Paramaters...");
// }

// hello();
// hello("Manish");

// m1();
// m2("Abhijeet");

// -------------------------------------

// function hello() {
//     function m1() {
//         console.log("Hello World!");
//     }

//     function m2(name) {
//         console.log("Hi,", name);
//     }

//     if (arguments.length === 0)
//         m1();
//     else if (arguments.length === 1)
//         m2(arguments[0]);
//     else
//         throw Error("Invalid Paramaters...");
// }

// hello();
// hello("Manish");

// // -------------------------------------

// var hello = (function () {
//     function m1() {
//         console.log("Hello World!");
//     }

//     function m2(name) {
//         console.log("Hi,", name);
//     }

//     return function () {
//         if (arguments.length === 0)
//             m1();
//         else if (arguments.length === 1)
//             m2(arguments[0]);
//         else
//             throw Error("Invalid Paramaters...");
//     }
// })();

// hello();
// hello("Manish");

// -----------------------------------------
// function hello() {
//     if (arguments.length === 0)
//         console.log("Hello World!");
//     else if (arguments.length === 1)
//         console.log("Hi,", arguments[0]);
//     else
//         throw Error("Invalid Paramaters...");
// }

// hello();
// hello("Manish");

// --------------------------------------- Assignment

// Create an Add Function which takes 2 or 3 arguments and returns the sum of the numbers
// Use both the approach to create the function

// var Add = (function () {
//     function m1(x, y) {
//         return x + y;
//     }

//     function m2(x, y, z) {
//         return x + y + z;
//     }

//     return function () {
//         if (arguments.length === 2)
//             return m1(arguments[0], arguments[1]);
//         else if (arguments.length === 3)
//             return m2(arguments[0], arguments[1], arguments[2]);
//         else
//             throw Error("Invalid Paramaters...");
//     }
// })();

function Add() {
    if (arguments.length === 2)
        return arguments[0] + arguments[1];
    else if (arguments.length === 3)
        return arguments[0] + arguments[1] + arguments[2];
    else
        throw Error("Invalid Paramaters...");
}

console.log(Add(2, 3));
console.log(Add(2, 3, 4));

try {
    console.log(Add(2));        // Show Error, if you are passing less than 2 or more than 3 arguments
} catch (e) {
    console.error(e.message);
}
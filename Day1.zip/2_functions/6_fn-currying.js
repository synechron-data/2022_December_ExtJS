// function greetings(message, name) {
//     console.log(message + ", " + name);
// }

// greetings("Good Afternoon", "Abhijeet");
// greetings("Good Afternoon", "Ramakant");
// greetings("Good Afternoon", "Sobodh");

// function Converter(toUnit, factor, offset, input) {
//     return [((offset + input) * factor).toFixed(2), toUnit].join("");
// }

// console.log(Converter(" INR", 82.76, 0, 100));
// console.log(Converter(" INR", 82.76, 0, 250));
// console.log(Converter(" INR", 82.76, 0, 699));
// console.log(Converter(" INR", 82.76, 0, 999));

// ----------------------------------------------

function greetings(message) {
    return function (name) {
        console.log(message + ", " + name);
    }
}

// const aGreet = greetings("Good Afternoon");
// aGreet("Abhijeet");
// aGreet("Ramakant");
// aGreet("Subodh");

// const eGreet = greetings("Good Evening");
// eGreet("Abhijeet");
// eGreet("Ramakant");
// eGreet("Subodh");

function Converter(toUnit, factor, offset) {
    return function (input) {
        return [((offset + input) * factor).toFixed(2), toUnit].join("");
    }
}

var usdToInrConverter = Converter(" INR", 82.76, 0);
console.log(usdToInrConverter(100));
console.log(usdToInrConverter(250));
console.log(usdToInrConverter(699));
console.log(usdToInrConverter(999));

var milesToKmConverter = Converter(" KM", 1.6, 0);
console.log(milesToKmConverter(100));
console.log(milesToKmConverter(250));
console.log(milesToKmConverter(699));
console.log(milesToKmConverter(999));
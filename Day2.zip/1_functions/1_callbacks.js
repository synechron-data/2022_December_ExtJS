// document.getElementById("b1").addEventListener("click", function () { });
// setInterval(function () { }, 2000);
// setTimeout(function () { }, 2000);

// $(document).ready(function () {
//     $("#b1").click(function () { });
// });

// ------------------------------------------

// // Dev 1
// function add(x, y) {
//     return x + y;
// }

// // Dev2
// function showResult(result) {
//     document.getElementById("divResult").innerHTML = result;
// }

// var result = add(2, 3);
// showResult(result);

// // ------------------------------------------

// // Dev 1
// function showResult(result) {
//     document.getElementById("divResult").innerHTML = result;
// }

// function add(x, y) {
//     var result = x + y;
//     showResult(result);
// }

// // Dev2
// add(2, 3);

// ------------------------------------------

// // Dev 1
// function add(x, y, cb) {
//     var result = x + y;
//     cb(result);
// }

// // Dev2
// function showResult(result) {
//     document.getElementById("divResult").innerHTML = result;
// }

// add(2, 3, showResult);

// add(2, 3, function (result) {
//     document.getElementById("pResult").innerHTML = result;
// });

// // ------------------------------------------

// // Dev 1
// function getString() {
//     var strArr = ["NodeJS", "ReactJS", "ExtJS", "Angular", "VueJS"];
//     var str = strArr[Math.floor(Math.random() * strArr.length)];
//     return str;
// }

// // Dev 2
// // var s = getString();
// // console.log(s);

// setInterval(function () {
//     var s = getString();
//     console.log(s);
// }, 2000);

// // What will happen if getString takes inderterministic time to execute
// // Call 1 = 1000
// // Call 2 = 3000
// // Call 3 = 1000

// ------------------------------------------

// Dev 1
function pushString(cb) {
    var strArr = ["NodeJS", "ReactJS", "ExtJS", "Angular", "VueJS"];
    setInterval(function () {
        var str = strArr[Math.floor(Math.random() * strArr.length)];
        cb(str);
    }, 2000);
}

// Dev 2
pushString(function (s) {
    console.log("C1 - ", s);
});

pushString(function (s) {
    console.log("C2 - ", s);
});

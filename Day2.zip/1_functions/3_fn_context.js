"use strict"

// // In ES ‘this’ refers to the parent of the function and the object through which the function was called
// function test1() {
//     console.log(this);
// }

// test1();
// window.test1();

// var test2 = function () {
//     console.log(this);
// }

// test2();
// window.test2();

// var p1 = {
//     id: 1,
//     test: function () {
//         console.log(this);
//     }
// };

// p1.test();

// console.log("Context of the file: ", this);

// ----------------------------------------------------- Switching Context

// var p1 = {
//     id: 1
// };

// var p2 = {
//     id: 2
// };

// function check(x, y) {
//     console.log(x, y);
//     console.log(this);
// }

// check(2, 3)
// check.call(p1, 2, 3);
// check.apply(p1, [2, 3]);

// var bindedToP1 = check.bind(p1);
// bindedToP1(2, 3);

// var bindedToP2 = check.bind(p2, 2, 3);
// bindedToP2();

// ----------------------------------------------------- Switching Context

// var p1 = {
//     id: 1,
//     name: "Manish",
//     toJson: function () {
//         console.log(JSON.stringify(this));
//     }
// };

// var p2 = {
//     personId: 2,
//     personName: "Abhijeet",
//     toJson: function () {
//         console.log(JSON.stringify(this));
//     }
// };

// p1.toJson();
// p2.toJson();

// var p1 = {
//     id: 1,
//     name: "Manish"
// };

// var p2 = {
//     personId: 2,
//     personName: "Abhijeet"
// };

// function toJson() {
//     console.log(JSON.stringify(this));
// }

// // toJson.call(p1);
// // toJson.call(p2);

// p1.toJson = toJson.bind(p1);
// p2.toJson = toJson.bind(p2);

// p1.toJson();
// p2.toJson();

// -----------------------------------------------------

var person = {
    age: 0,
    growOld: function () {
        console.log("growOld executed, under context:", this);
        this.age += 1;
    }
}

// console.log(person.age);

// person.growOld();
// console.log(person.age);

// person.growOld();
// console.log(person.age);

// person.growOld();
// console.log(person.age);

// ---------------------------------------------------------------- Problem
// In ES ‘this’ refers to the parent of the function and the object through which the function was called (invoked)

// var btn = document.createElement("button");
// btn.innerHTML = "Click";

// var btnArea = document.getElementById("btnArea");
// btnArea.appendChild(btn);

// btn.addEventListener("click", person.growOld);

// window.setInterval(person.growOld, 2000);

// ---------------------------------------------------------------- Solution
// In ES ‘this’ refers to the parent of the function and the object through which the function was called (invoked)

var btn = document.createElement("button");
btn.innerHTML = "Click";

var btnArea = document.getElementById("btnArea");
btnArea.appendChild(btn);

btn.addEventListener("click", person.growOld.bind(person));

window.setInterval(person.growOld.bind(person), 2000);
// function applyMixins(derivedCtorFn, baseCtorFns) {
//     baseCtorFns.forEach(function (baseCtor) {
//         Object.getOwnPropertyNames(baseCtor.prototype).forEach(function (name) {
//             Object.defineProperty(derivedCtorFn.prototype, name,
//                 Object.getOwnPropertyDescriptor(baseCtor.prototype, name) || Object.create(null));
//         })
//     });
// }

// var FocusableControl = (function () {
//     function FocusableControl() { }

//     FocusableControl.prototype.focus = function () {
//         return "The control is in focus";
//     }

//     return FocusableControl;
// })();

// var SelectableControl = (function () {
//     function SelectableControl() { }

//     SelectableControl.prototype.select = function () {
//         return "The control is selected";
//     }

//     return SelectableControl;
// })();

// var Button = (function () {
//     function Button() { };

//     return Button;
// })();

// applyMixins(Button, [FocusableControl, SelectableControl]);

// var button = new Button();
// console.log(button.focus());
// console.log(button.select());

// -----------------------------------------------------

function extend(target, source) {
    for (var key in source) {
        if (source.hasOwnProperty(key)) {
            target[key] = source[key];
        }
    }
    return target;
}

var FocusableControlFns = {
    focus: function () {
        return "The control is in focus";
    }
}

var SelectableControlFns = {
    select: function () {
        return "The control is selected";
    }
};

var Button = (function () {
    function Button() { };

    return Button;
})();

extend(Button.prototype, FocusableControlFns);
extend(Button.prototype, SelectableControlFns);

var button = new Button();
console.log(button.focus());
console.log(button.select());
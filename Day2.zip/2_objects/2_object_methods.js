// // // ---------------------------------------------------- Object.assign (Shallow Copy) - ES 6

// var source = { id: 1, name: "Manish", address: { city: "Pune" } };

// // // var target = {};
// // // target.id = source.id;
// // // target.name = source.name;
// // // target.address = source.address;

// // // Create a custom method to do shallow copy
// // function mergeObjects() {
// //     var resultObj = {};

// //     for (var i = 0; i < arguments.length; i++) {
// //         var obj = arguments[i];
// //         var keys = Object.keys(obj);
// //         for (var j = 0; j < keys.length; j++) {
// //             resultObj[keys[j]] = obj[keys[j]];
// //         }
// //     }

// //     return resultObj;
// // }

// // // var target = mergeObjects({ test: "test" }, source);

// // Object.merge = mergeObjects;
// // var target = Object.merge({ test: "test" }, source);

// // // var target = Object.assign({ test: "test" }, source);

// // Deep Copy
// var target = JSON.parse(JSON.stringify(source));

// target.name = "Abhijeet";
// target.address.city = "Mumbai";

// console.log(source);
// console.log(target);

// ------------------------------------------------------------ Object.create
// // Creates a new object, using an existing object as the prototype of the newly created object.

// var source = { id: 1, name: "Manish", address: { city: "Pune" } };

// let target1 = Object.assign({}, source);
// let target2 = Object.create(source);

// console.log("Source: ", source);
// console.log("Assign: ", target1);
// console.log("Create: ", target2);

// ------------------------------------------------------------

// var source = { id: 1, name: "Manish" };

// // Add a New Property
// source.city = "Pune";
// console.log(source);

// // Delete a Property
// delete source.name;
// console.log(source);

// // Modify a Property Value
// source.id = 1000;
// console.log(source);

// // ----------------------------------
// // Add a New Property - Not Allowed
// // Delete a Property - Allowed
// // Modify a Property Value - Allowed

// Object.preventExtensions(source);

// delete source.name;
// console.log(source);

// source.id = 1000;
// console.log(source);

// if (Object.isExtensible(source)) {
//     source.city = "Pune";
//     console.log(source);
// } else {
//     console.error("Object is not extensible...");
// }

// // ----------------------------------
// // Add a New Property - Not Allowed
// // Delete a Property - Not Allowed
// // Modify a Property Value - Allowed

// Object.seal(source);

// source.id = 1000;
// console.log(source);

// if (!Object.isSealed(source)) {
//     source.city = "Pune";
//     console.log(source);

//     delete source.name;
//     console.log(source);
// } else {
//     console.error("You cannot add or delete properties from the object...");
// }

// ----------------------------------
// Add a New Property - Not Allowed
// Delete a Property - Not Allowed
// Modify a Property Value - Not Allowed

// Object.freeze(source);

// if (!Object.isFrozen(source)) {
//     source.city = "Pune";
//     console.log(source);

//     delete source.name;
//     console.log(source);

//     source.id = 1000;
//     console.log(source);
// } else {
//     console.error("Object is freezed...");
// }

// ----------------------------------------

var s = "Manish";

String.prototype.hello = function() {
    console.log("Custom hello on string type");
};

var name = "Abhijeet";

console.log(s);
s.hello();
name.hello();
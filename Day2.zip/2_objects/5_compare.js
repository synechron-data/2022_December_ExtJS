function CL_Counter(by = 1) {
    var count = 0;
    var interval = by;

    return {
        next: function () {
            return count += interval;
        },
        prev: function () {
            return count -= interval;
        }
    };
}

function FN_Counter(by) {
    this._count = 0;
    this._interval = by || 1;

    this.next = function () {
        return this._count += this._interval;
    }

    this.prev = function () {
        return this._count -= this._interval;
    }
}

var PT_Counter = (function () {
    function PT_Counter(by) {
        this._count = 0;
        this._interval = by || 1;
    }

    PT_Counter.prototype.next = function () {
        return this._count += this._interval;
    }

    PT_Counter.prototype.prev = function () {
        return this._count -= this._interval;
    }

    return PT_Counter;
})();

(function() {
    var clStTime = new Date();
    for (let i = 0; i < 200000; i++) {
        var obj = CL_Counter(i);
    }
    var clEnTime = new Date();

    var fnStTime = new Date();
    for (let i = 0; i < 200000; i++) {
        var obj = new FN_Counter(i);
    }
    var fnEnTime = new Date();

    var ptStTime = new Date();
    for (let i = 0; i < 200000; i++) {
        var obj = new PT_Counter(i);
    }
    var ptEnTime = new Date();

    var clTime = clEnTime.getTime() - clStTime.getTime();
    var fnTime = fnEnTime.getTime() - fnStTime.getTime();
    var ptTime = ptEnTime.getTime() - ptStTime.getTime();

    console.log("Closure: ", clTime, "ms");
    console.log("Function: ", fnTime, "ms");
    console.log("Prototype: ", ptTime, "ms");
})();
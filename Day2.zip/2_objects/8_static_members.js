// Create a BankAccount Class with bankName and accName as data properties and create accessor properties 
// to access the data outside using instance.

// var BankAccount = (function () {
//     function BankAccount(accName) {
//         this._accName = accName;
//     }

//     Object.defineProperty(BankAccount, "BankName", {
//         set: function (value) {
//             BankAccount._bankName = value;
//         }
//     });

//     Object.defineProperty(BankAccount.prototype, "BankName", {
//         get: function () {
//             return BankAccount._bankName;
//         }
//     });

//     Object.defineProperty(BankAccount.prototype, "AccountName", {
//         get: function () {
//             return this._accName;
//         }
//     });

//     return BankAccount;
// })();

// BankAccount.BankName = "HDFC";

// var a1 = new BankAccount("Manish");
// console.log("\nBank Name:", a1.BankName);
// console.log("Account Holder Name:", a1.AccountName);

// var a2 = new BankAccount("Abhijeet");
// console.log("\nBank Name:", a2.BankName);
// console.log("Account Holder Name:", a2.AccountName);

// BankAccount.BankName = "ICICI";
// console.log("\nBank Name:", a1.BankName);
// console.log("Account Holder Name:", a1.AccountName);

// console.log("\nBank Name:", a2.BankName);
// console.log("Account Holder Name:", a2.AccountName);

// -------------------------------------------------

var BankAccount = (function () {
    function BankAccount(accName) {
        this._accName = accName;
    }

    BankAccount.setBankName = function (value) {
        BankAccount._bankName = value;
    }

    BankAccount.prototype.getBankName = function () {
        return BankAccount._bankName;
    }

    BankAccount.prototype.getAccountName = function () {
        return this._accName;
    }

    return BankAccount;
})();

BankAccount.setBankName("HDFC");

var a1 = new BankAccount("Manish");
console.log("\nBank Name:", a1.getBankName());
console.log("Account Holder Name:", a1.getAccountName());

var a2 = new BankAccount("Abhijeet");
console.log("\nBank Name:", a2.getBankName());
console.log("Account Holder Name:", a2.getAccountName());

BankAccount.setBankName("ICICI");
console.log("\nBank Name:", a1.getBankName());
console.log("Account Holder Name:", a1.getAccountName());

console.log("\nBank Name:", a2.getBankName());
console.log("Account Holder Name:", a2.getAccountName());
// var employees = new Array();
// var employees = new Array(2);

// employees.push("Manish");
// employees.push("Abhijeet");
// employees.push("Ramakant");

// employees.unshift("Manish");
// employees.unshift("Abhijeet");
// employees.unshift("Ramakant");

// employees[0] = "Manish";
// employees.splice(1, 1, "Abhijeet")

// var employees = new Array("Subodh", "Ram");
// var employees = new Array(10, 20);

// var employees = [10, 20, 30, 40, 50];

// console.log(employees);
// console.log(typeof employees);
// console.log(employees.length);

// ------------------------------------------

var employees = [
    { id: 1, name: "Manish" },
    { id: 2, name: "Varun" },
    { id: 3, name: "Paresh" },
    { id: 4, name: "Devesh" },
    { id: 5, name: "Atul" },
    { id: 6, name: "Abhishek" }
];

// for (var i = 0; i < employees.length; i++) {
//     console.log(i + "\t" + JSON.stringify(employees[i]));
// }

// for(var i in employees) {
//     console.log(i + "\t" + JSON.stringify(employees[i]));
// }

// employees.forEach(function(item, index, arr) {
//     console.log(index + "\t" + JSON.stringify(item));
// });

// --------------------------------------------

// Create a new Array with all the Names in uppercase from employees Array (Transformation)
// var names = employees.map(function (employee) { return employee.name.toUpperCase(); });
// console.log(names);

// Create a new Array with all the Ids from employees Array (Transformation)
var ids = employees.map(function (employee) { return employee.id; });
console.log(ids);

// Write a code which will add all numbers in the ids array (Sum of all ids)
var sum = ids.reduce(function (acc, cur) { return acc + cur; });
console.log(sum);

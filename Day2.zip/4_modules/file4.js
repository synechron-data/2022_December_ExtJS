var calculator = (function () {
    function add(x, y) {
        return x + y;
    }

    function sub(x, y) {
        return x + y;
    }

    function mul(x, y) {
        return x + y;
    }

    function divide(x, y) {
        return x + y;
    }

    return Object.freeze({
        addition: add,
        substraction: sub,
        multiply: mul
    });
})();
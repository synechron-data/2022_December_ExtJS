var bookTitleEl = Ext.get('book-title');
console.log(bookTitleEl);
console.log('Book Title ID: ' + bookTitleEl.id);
console.log(bookTitleEl.dom);

var authorsListItemEls = Ext.select("ul#authors li");
console.log(authorsListItemEls);
// authorsListItemEls.hide();

var authorsListItemNEls = Ext.query('ul#authors li');
console.log(authorsListItemNEls);
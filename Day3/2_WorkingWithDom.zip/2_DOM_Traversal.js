var dataPackageEl = Ext.select('ul#whats-new li').item(2);
console.log(dataPackageEl);
console.log(dataPackageEl.dom.innerHTML);

// previous list item
var drawingEl = dataPackageEl.prev();
console.log(drawingEl.dom.innerHTML);

// next list item
var enhancedGridEl = dataPackageEl.next();
console.log(enhancedGridEl.dom.innerHTML);

// get the first and last child of an Ext.Element
var whatsNewEl = Ext.get('whats-new');

var chartingEl = whatsNewEl.first();
console.log(chartingEl.dom.innerHTML);

var powerfulThemingEl = whatsNewEl.last();
console.log(powerfulThemingEl.dom.innerHTML);

// Direct Parents and Children
var dataPackageEl = Ext.select('ul#whats-new li').item(2);
console.log(dataPackageEl.parent().id);

var whatsNewEl = Ext.get('whats-new');

// get the first child LI element
var firstListItemChildEl = whatsNewEl.child('li');
console.log(firstListItemChildEl.dom.innerHTML);
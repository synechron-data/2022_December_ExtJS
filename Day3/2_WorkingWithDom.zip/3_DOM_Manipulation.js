var bookTitleEl = Ext.get('book-title');

// Update Element's font-size
bookTitleEl.setStyle('font-size', '1.5em');

// Make the heading red and give it a bottom border at the same time
bookTitleEl.setStyle({
    color: 'red',
    borderBottom: '3px solid red'
});

// Add a CSS Class
bookTitleEl.addCls('book-title');

// To Remove Class
// bookTitleEl.removeCls('book-title');

// Showing and Hiding as Element
bookTitleEl.hide();

setTimeout(function () {
    bookTitleEl.show();
    bookTitleEl.update('How to Make AWESOME Web Apps');
}, 3000);

var newClassSystemConfig = {
    tag: 'li',
    html: 'New Class System'
};

var whatsNewListEl = Ext.get('whats-new');

Ext.core.DomHelper.append(whatsNewListEl, newClassSystemConfig);
Ext.core.DomHelper.append(whatsNewListEl, '<li>Plain HTML String</li>');

// Insert Before or After
var whatsNewListEl = Ext.get('whats-new');

// Ext.core.DomHelper.insertBefore(whatsNewListEl.first(), {
//     tag: 'li',
//     html: 'Infinite Scrolling'
// });

Ext.core.DomHelper.insertAfter(whatsNewListEl.first(), {
    tag: 'li',
    html: 'Infinite Scrolling'
});

// Using templates to insert elements
var itemTpl = Ext.core.DomHelper.createTemplate({
    tag: 'li',
    html: '{newFeature}'
});

itemTpl.append('whats-new', { newFeature: 'Row Editor' });
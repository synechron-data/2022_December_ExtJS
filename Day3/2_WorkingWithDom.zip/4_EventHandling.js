var el = Ext.get('my-div');

// The scope, defined by this being passed in as the third parameter, is the browser's window.
// el.on('click', function(e, target, options) {
//     console.log('The Element was clicked!');
//     console.log(this.id);
// }, this);

// Defining multiple event handlers at once
// el.on({
//     click: function (e, target, options) {
//         console.log('The Element was clicked!');
//         console.log(this.id);
//     },
//     contextmenu: function (e, target, options) {
//         console.log('The Element was right-clicked!');
//         console.log(this.id);
//     },
//     scope: this
// });

// Defining event handlers in config objects
el.hide();

Ext.create('Ext.panel.Panel', {
    title: 'The Paradise',
    html: 'An Example Panel!',
    renderTo: Ext.getBody(),
    width: 500,
    listeners: {
        afterrender: function () {
            console.log('The Panel is rendered!');
            console.log(this);
        },
        scope: this
    }
});
var whatsNewEl = Ext.get('whats-new');

whatsNewEl.on('click', function(e, target, options) {
    console.log(target.innerHTML);
}, this, {
    delegate: 'li'
    // stopEvent
    // preventDefault
    // stopPropagation
    // delay
    // buffer
});

var toolbarEl = Ext.get('toolbar');

toolbarEl.on('click', function(e, target, options) {
    if (e.getTarget('a.add')) {
        console.log("Add was clicked...");
    } else if (e.getTarget('a.edit')) {
        console.log("Edit was clicked...");
    } else if (e.getTarget('a.delete')) {
        console.log("Delete was clicked...");
    }
}, this, {
    delegate: 'a'
});
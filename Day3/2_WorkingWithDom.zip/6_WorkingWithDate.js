var date = new Date(2022, 6, 6, 22, 30);

Ext.Date.patterns = {
    ISO8601Long: "Y-m-d H:i:sP",
    ISO8601Short: "Y-m-d",
    ShortDate: "n/j/y",
    FullDateTime: "l, F d, Y g:i:s A",
    LongTime: "g:i:s A",
    SortableDateTime: "Y-m-d\\TH:i:s",
    UniversalSortableDateTime: "Y-m-d H:i:sO"
};

console.log(Ext.Date.format(date, Ext.Date.patterns.ISO8601Long));
console.log(Ext.Date.format(date, Ext.Date.patterns.ISO8601Short));
console.log(Ext.Date.format(date, Ext.Date.patterns.ShortDate));
console.log(Ext.Date.format(date, Ext.Date.patterns.FullDateTime));
console.log(Ext.Date.format(date, Ext.Date.patterns.LongTime));
console.log(Ext.Date.format(date, Ext.Date.patterns.SortableDateTime));
console.log(Ext.Date.format(date, Ext.Date.patterns.UniversalSortableDateTime));

console.log(Ext.Date.format(date, 'l, \\t\\he jS \\of F Y h:i:s A'));

console.log(Ext.Date.parse("3", 'n'));
console.log(Ext.Date.parse("2022-05-17", "Y-m-d"));
console.log(Ext.Date.parse("2011-11-31", "Y-m-d", true));

console.log(Ext.Date.between(new Date('07/01/2022'), new Date('05/01/2022'), new Date('09/01/2011')));
console.log(Ext.Date.add(new Date('09/30/2011'), Ext.Date.YEAR, -1));
console.log(Ext.Date.getLastDateOfMonth(new Date('07/01/2011')));

console.log(Ext.Date.isDST(new Date('07/01/2011')));

console.log(Ext.Date.isValid(2011, 29, 2));

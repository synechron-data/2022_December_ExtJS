Ext.onReady(function () {
    Ext.Ajax.request({
        url: 'data.json',
        success: function (response, options) {
            console.log('The Success function was called.');
            console.log(response.responseText);
        },
        failure: function (response, options) {
            console.log('The Failure function was called.');

            var statusCode = response.status;
            var statusText = response.statusText;
            console.log(statusCode + ' (' + statusText + ')');
        },
        callback: function (options, success, response) {
            console.log('The Callback function was called.');
            console.log('Successful Request? ' + success);
        },
        disableCaching: true,
        timeout: 60000 //60 seconds (default is 30)
    })
});
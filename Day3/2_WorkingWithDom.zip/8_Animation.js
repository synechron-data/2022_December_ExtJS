Ext.onReady(function () {
    var el = Ext.get('animate');

    // el.puff({
    //     easing: 'easeOut',
    //     duration: 2000,
    //     useDisplay: false
    // });

    // el.switchOff({
    //     easing: 'easeIn',
    //     duration: 2000,
    //     remove: false,
    //     useDisplay: false
    // });

    el.slideIn('l', {
        easing: 'easeOut',
        duration: 2000
    });
});
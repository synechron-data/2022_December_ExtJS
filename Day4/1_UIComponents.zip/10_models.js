// Ext.define('Post', {
//     extend: 'Ext.data.Model',
//     fields: [
//         { name: 'userid', type: 'int' },
//         { name: 'id', type: 'int' },
//         { name: 'title', type: 'string' },
//         { name: 'body', type: 'string' },
//     ],

//     validations: [
//         { type: 'presence', field: 'id' },
//         { type: 'presence', field: 'title' },
//         { type: 'presence', field: 'body' }
//     ],

//     changeTitle: function () {
//         this.set('title', "Title Changed");
//     }
// });

// // var post = Ext.create('Post', {
// //     id: 1,
// //     title: 'Hello',
// //     body: 'Hello World!'
// // });

// // console.log(post.get('id'));
// // console.log(post.get('title'));
// // console.log(post.get('body'));

// // post.changeTitle();

// // console.log(post.get('id'));
// // console.log(post.get('title'));
// // console.log(post.get('body'));

// var post = Ext.create('Post', {});

// var errors = post.validate();
// console.log(errors);

// // console.log(post.get('id'));
// // console.log(post.get('title'));
// // console.log(post.get('body'));

// ---------------------------------------

// Ext.define('User', {
//     extend: 'Ext.data.Model',
//     fields: [
//         { name: 'id', type: 'int' },
//         { name: 'name', type: 'string' },
//         { name: 'username', type: 'string' },
//         { name: 'email', type: 'string' },
//     ],
//     hasMany: {model: 'Post', name: posts}
// });

// Ext.define('Post', {
//     extend: 'Ext.data.Model',
//     fields: [
//         { name: 'userid', type: 'int' },
//         { name: 'id', type: 'int' },
//         { name: 'title', type: 'string' },
//         { name: 'body', type: 'string' },
//     ],

//     belongsTo: 'User'
// });

// -----------------------------------

Ext.define('Post', {
    extend: 'Ext.data.Model',
    fields: [
        { name: 'userId', type: 'int' },
        { name: 'id', type: 'int' },
        { name: 'title', type: 'string' },
        { name: 'body', type: 'string' },
    ],
    proxy: {
        type: 'rest',
        url: 'https://jsonplaceholder.typicode.com/posts',
        reader: {
            type: 'json',
            root: 'data'
        },
        write: {
            type: 'json'
        }
    }
});

// var Post = Ext.ModelManager.getModel('Post');
// Post.load(2, {
//     success: function (data) {
//         console.log(data);
//     }
// });

// var post = Ext.create('Post', {
//     id: 1
// });

// // post.set('title', 'Changed');
// // post.save();

// post.destroy();

var store = Ext.create('Ext.data.Store', {
    model: 'Post'
});

store.load();

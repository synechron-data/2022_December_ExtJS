Ext.define('Employee', {
    extend: 'Ext.data.Model',
    fields: [
        { name: 'id', type: 'int', useNull: true },
        'firstname',
        'lastname',
        'email'
    ],
    validations: [
        {
            type: 'length',
            field: 'firstname',
            min: 1
        },
        {
            type: 'length',
            field: 'lastname',
            min: 1
        },
        {
            type: 'length',
            field: 'email',
            min: 1
        }
    ]
});

Ext.onReady(function () {
    var store = Ext.create('Ext.data.Store', {
        autoLoad: true,
        autoSync: true,
        model: 'Employee',
        proxy: {
            type: 'rest',
            url: 'http://localhost:8000/employee',
            reader: {
                type: 'json',
                root: 'data'
            },
            writer: {
                type: 'json'
            }
        },
        listeners: {
            write: function (store, operation) {
                var record = operation.getRecords()[0];
                var name = Ext.String.capitalize(operation.action);
                var verb;

                if (name == 'Destroy') {
                    record = operation.records[0];
                    verb = 'Destroyed';
                } else {
                    verb = name + 'd';
                }

                Ext.example.msg(name, Ext.String.format("{0} user: {1}", verb, record.getId()));
            }
        }
    });

    var rowEditing = Ext.create('Ext.grid.plugin.RowEditing');

    var grid = Ext.create('Ext.grid.Panel', {
        renderTo: document.body,
        plugins: [rowEditing],
        width: 400,
        height: 300,
        frame: true,
        title: 'Users',
        iconCls: 'icon-user',
        store: store,
        columns: [
            {
                text: 'ID',
                width: 40,
                sortable: true,
                dataIndex: 'id'
            },
            {
                text: 'Email',
                flex: 1,
                sortable: true,
                dataIndex: 'email',
                field: {
                    xtype: 'textfield'
                }
            },
            {
                header: 'Firstname',
                width: 80,
                sortable: true,
                dataIndex: 'firstname',
                field: {
                    xtype: 'textfield'
                }
            },
            {
                text: 'Lastname',
                width: 80,
                sortable: true,
                dataIndex: 'lastname',
                field: {
                    xtype: 'textfield'
                }
            }
        ],
        dockedItems: [{
            xtype: 'toolbar',
            items: [{
                text: 'Add',
                handler: function () {
                    store.insert(0, new Employee());
                    rowEditing.startEdit(0, 0);
                }
            }, '-', {
                itemId: 'delete',
                text: 'Delete',
                disabled: true,
                handler: function () {
                    var selection = grid.getView().getSelectionModel().getSelection()[0];
                    if (selection) {
                        store.remove(selection);
                    }
                }
            }]
        }]
    });

    grid.getSelectionModel().on('selectionchange', function (selModel, selections) {
        grid.down('#delete').setDisabled(selections.length === 0);
    });
});
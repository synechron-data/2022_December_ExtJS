var data = {
    name: 'Tommy Maintz',
    title: 'Lead Developer',
    company: 'Sencha Inc.',
    email: 'tommy@sencha.com',
    address: '5 Cups Drive',
    city: 'Palo Alto',
    state: 'CA',
    zip: '44102',
    drinks: ['Coffee', 'Soda', 'Water'],
    kids: [
        {
            name: 'Joshua',
            age: 3
        },
        {
            name: 'Matthew',
            age: 2
        },
        {
            name: 'Solomon',
            age: 0
        }
    ]
};

// var tpl = new Ext.XTemplate(
//     '<p>Kids: ',
//     '<tpl for=".">',
//     '<p>{#}. {name}</p>',
//     '</tpl></p>'
// );
// tpl.overwrite(Ext.getBody(), data.kids);

// var tpl = new Ext.XTemplate(
//     '<p>Name: {name}</p>',
//     '<p>Kids: ',
//     '<tpl for="kids">',
//     '<tpl if="age &gt; 1">',
//     '<p>{#}. {name}</p>',
//     '</tpl>',
//     '</tpl></p>'
// );
// tpl.overwrite(Ext.getBody(), data);

// ----------------------------------- special {.} variable inside a loop
// var tpl = new Ext.XTemplate(
//     '<p>{name}\'s favorite beverages:</p>',
//     '<tpl for="drinks">',
//         '<div> - {.}</div>',
//     '</tpl>'
// );
// tpl.overwrite(Ext.getBody(), data);

// ------------------------parent object's members via the parent 
// var tpl = new Ext.XTemplate(
//     '<p>Name: {name}</p>',
//     '<p>Kids: ',
//     '<tpl for="kids">',
//         '<tpl if="age &gt; 1">',
//             '<p>{name}</p>',
//             '<p>Dad: {parent.name}</p>',
//         '</tpl>',
//     '</tpl></p>'
// );
// tpl.overwrite(Ext.getBody(), data);

// ------------------------------- Basic math support (+ - * /)
// var tpl = new Ext.XTemplate(
//     '<p>Name: {name}</p>',
//     '<p>Kids: ',
//     '<tpl for="kids">',
//         '<tpl if="age &gt; 1">',  // <-- Note that the > is encoded
//             '<p>{#}: {name}</p>',  // <-- Auto-number each item
//             '<p>In 5 Years: {age+5}</p>',  // <-- Basic math
//             '<p>Dad: {parent.name}</p>',
//         '</tpl>',
//     '</tpl></p>'
// );

// tpl.overwrite(Ext.getBody(), data);

// --------------------------------- inline code with special built-in template variables
// var tpl = new Ext.XTemplate(
//     '<p>Name: {name}</p>',
//     '<p>Company: {[values.company.toUpperCase() + ", " + values.title]}</p>',
//     '<p>Kids: ',
//     '<tpl for="kids">',
//         '<div class="{[xindex % 2 === 0 ? "even" : "odd"]}">',
//         '{name}',
//         '</div>',
//     '</tpl></p>'
//  );

// tpl.overwrite(Ext.getBody(), data);

// --------------------------------- Template member functions
var tpl = new Ext.XTemplate(
    '<p>Name: {name}</p>',
    '<p>Kids: ',
    '<tpl for="kids">',
    '<tpl if="this.isGirl(name)">',
    '<p>Girl: {name} - {age}</p>',
    '</tpl>',
    // use opposite if statement to simulate 'else' processing:
    '<tpl if="this.isGirl(name) == false">',
    '<p>Boy: {name} - {age}</p>',
    '</tpl>',
    '<tpl if="this.isBaby(age)">',
    '<p>{name} is a baby!</p>',
    '</tpl>',
    '</tpl></p>',
    {
        // XTemplate configuration:
        disableFormats: true,
        // member functions:
        isGirl: function (name) {
            return name == 'Sara Grace';
        },
        isBaby: function (age) {
            return age < 1;
        }
    }
);

tpl.overwrite(Ext.getBody(), data);

var storeForTreeA = Ext.create('Ext.data.TreeStore', {
    root: {
        expanded: true,
        children: [{
            text: "Item One",
            leaf: true
        }, {
            text: "Item Two",
            leaf: true
        }, {
            text: "Item Three",
            leaf: true
        }, {
            text: "Item Four",
            leaf: true
        }]
    }
});

var treeA = Ext.create('Ext.tree.Panel', {
    title: 'Tree One (drag from here)',
    width: 500,
    height: 300,
    store: storeForTreeA,
    viewConfig: {
        plugins: {
            ptype: 'treeviewdragdrop'
        }
    },
    renderTo: Ext.getBody(),
    style: 'marging: 50px'
});

var storeForTreeB = Ext.create('Ext.data.TreeStore', {
    root: {
        expanded: true,
        children: [{
            text: "Item Five",
            leaf: true
        }]
    }
});

var treeB = Ext.create('Ext.tree.Panel', {
    title: 'Tree Two (drop here)',
    width: 500,
    height: 300,
    store: storeForTreeB,
    viewConfig: {
        plugins: {
            ptype: 'treeviewdragdrop',
            enableDrop: true,
            enableDrag: false,
            allowContainerDrop: true
        }
    },
    renderTo: Ext.getBody(),
    style: 'marging: 50px'
});
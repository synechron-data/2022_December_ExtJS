// Ext.create('Ext.panel.Panel', {
//     title: 'Panel Header',
//     width: 500,
//     height: 200,
//     bodyPadding: 10,
//     html: '<h1>Panel Content</h1>',
//     dockedItems: [{
//         xtype: 'toolbar',
//         dock: 'top',
//         items: [{
//             xtype: 'button',
//             text: 'Click me'
//         }, '->', 'Docked toolbar at the top']
//     }, {
//         xtype: 'toolbar',
//         dock: 'bottom',
//         items: [{
//             xtype: 'button',
//             text: 'Click me'
//         }, '->', 'Docked toolbar at the bottom']
//     }],
//     renderTo: Ext.getBody(),
//     style: 'margin: 50px'
// });

// ------------------------------------------
// Ext.create('Ext.panel.Panel', {
//     title: 'Panel Header',
//     width: 500,
//     height: 200,
//     bodyPadding: 10,
//     html: '<h1>Panel Content</h1>',
//     fbar: ['Docked toolbar at the bottom (on Footer)', {
//         xtype: 'button',
//         text: 'Click me'
//     }],
//     lbar: ['lbar'],
//     rbar: ['rbar'],
//     tbar: ['tbar'],
//     bbar: ['bbar'],
//     renderTo: Ext.getBody(),
//     style: 'margin: 50px'
// });

// ------------------------------------------ Docking items at runtime
var panel = Ext.create('Ext.panel.Panel', {
    title: 'Panel Header',
    width: 500,
    height: 200,
    bodyPadding: 10,
    html: '<h1>Panel Content</h1>',
    renderTo: Ext.getBody(),
    style: 'margin: 50px'
});

panel.addDocked({
    dock: 'top',
    xtype: 'toolbar',
    items: {
        text: 'button'
    }
});
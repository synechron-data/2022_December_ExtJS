Ext.tip.QuickTipManager.init();

Ext.create('Ext.tab.Panel', {
    width: 500,
    height: 200,
    style: 'margin: 50px',
    renderTo: Ext.getBody(),
    items: [
        {
            title: 'Tab One',
            tabConfig: {
                tooltip: 'Tab One Tooltip Text'
            },
            html : 'A simple tab'
        },
        {
            title: 'Tab Two',
            tabConfig: {
                tooltip: 'Tab Two Tooltip Text'
            }
        },
        {
            title: 'Tab Three',
            tabConfig: {
                tooltip: 'Tab Three Tooltip Text'
            }
        }
    ]
});
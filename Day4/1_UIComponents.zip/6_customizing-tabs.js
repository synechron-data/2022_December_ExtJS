var tabPanel = Ext.create('Ext.tab.Panel', {
    width: 500,
    height: 200,
    style: 'margin: 50px',
    renderTo: Ext.getBody(),
    tbar: [{
        text: 'Switch Icon',
        handler: function () {
            tabPanel.items.get(0).tab.setIconCls('icon-tick');
        }
    }, {
        text: 'Toggle Tab',
        handler: function () {
            var tab = tabPanel.items.get(1).tab;
            tab.setVisible(!tab.isVisible());
        }
    }],
    items: [
        {
            title: 'Tab One',
            tabConfig: {
                cls: 'x-btn-text-icon',
                iconCls: 'icon-refresh'
            },
            html: 'This is Tab One'
        },
        {
            title: 'Tab Two',
            tabConfig: {

            },
            html: 'This is Tab Two'
        },
        {
            title: 'Tab Three',
            tabConfig: {

            },
            html: 'This is Tab Three'
        }
    ],
    tabPosition: 'bottom'
});
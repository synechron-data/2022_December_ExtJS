var telNumberVType = {
    telNumber: function (val, field) {
        // function executed when field is validated
        // return true when field's value (val) is valid
        // return true;
        // return false;

        var telNumberRegex = /^\d{4}\-\d{3}\-\d{4}$/;
        return telNumberRegex.test(val);
    },
    telNumberText: 'Your Telephone Number must only include numbers and hyphens',
    telNumberMask: /[\d\-]/
};

// console.log(Ext.form.field.VTypes);
Ext.apply(Ext.form.field.VTypes, telNumberVType);
console.log(Ext.form.field.VTypes);

var form = Ext.create('Ext.form.Panel', {
    title: 'Support Ticket Request',
    width: 650,
    height: 500,
    renderTo: Ext.getBody(),
    style: 'margin: 50px',
    items: [
        {
            xtype: 'container',
            layout: 'hbox',
            items: [
                {
                    xtype: 'textfield',
                    fieldLabel: 'First Name',
                    name: 'FirstName',
                    labelAlign: 'top',
                    cls: 'field-margin',
                    flex: 1
                },
                {
                    xtype: 'textfield',
                    fieldLabel: 'Last Name',
                    name: 'LastName',
                    labelAlign: 'top',
                    cls: 'field-margin',
                    flex: 1
                }
            ]
        },
        {
            xtype: 'container',
            layout: 'column',
            items: [
                {
                    xtype: 'textfield',
                    fieldLabel: 'Email Address',
                    name: 'EmailAddress',
                    labelAlign: 'top',
                    cls: 'field-margin',
                    columnWidth: 0.6,
                    vtype: 'email'          // Only one - alpha, alphnum, url
                },
                {
                    xtype: 'fieldcontainer',
                    layout: 'hbox',
                    fieldLabel: 'Tel. Number',
                    labelAlign: 'top',
                    cls: 'field-margin',
                    columnWidth: 0.4,
                    items: [
                        {
                            xtype: 'textfield',
                            name: 'TelNumberCode',
                            style: 'margin-right: 5px',
                            flex: 2
                        },
                        {
                            xtype: 'textfield',
                            name: 'TelNumber',
                            flex: 4,
                            vtype: 'telNumber'
                        }
                    ]
                }
            ]
        },
        {
            xtype: 'container',
            layout: 'hbox',
            items: [
                {
                    xtype: 'textarea',
                    fieldLabel: 'Request Details',
                    name: 'RequestDetails',
                    labelAlign: 'top',
                    cls: 'field-margin',
                    height: 250,
                    flex: 2
                },
                {
                    xtype: 'checkboxgroup',
                    fieldLabel: 'Request Type',
                    name: 'RequestType',
                    labelAlign: 'top',
                    cls: 'field-margin',
                    columns: 1,
                    vertical: true,
                    items: [
                        { xtype: 'checkbox', boxLabel: 'Type 1', name: 'RequestType1', inputValue: '1' },
                        { xtype: 'checkbox', boxLabel: 'Type 2', name: 'RequestType2', inputValue: '2' },
                        { xtype: 'checkbox', boxLabel: 'Type 3', name: 'RequestType3', inputValue: '3' },
                        { xtype: 'checkbox', boxLabel: 'Type 4', name: 'RequestType4', inputValue: '4' },
                        { xtype: 'checkbox', boxLabel: 'Type 5', name: 'RequestType5', inputValue: '5' },
                        { xtype: 'checkbox', boxLabel: 'Type 6', name: 'RequestType6', inputValue: '6' }
                    ],
                    flex: 1
                }
            ]
        },
        {
            xtype: 'filefield',
            name: 'attachment',
            fieldLabel: 'Attachment',
            width: 450,
            cls: 'field-margin',
            buttonText: 'Select Attachment...'
        }
    ],
    buttons: [{
        text: 'Submit Form',
        handler: function () {
            console.log('Form Submitted');
            // console.log(form.getForm().getValues());
            // form.getForm().submit({
            //     url: '/urltosubmitform',
            //     success: function(form, action) {

            //     },
            //     failure: function(form, action) {

            //     },
            // });
        }
    }]
});

// // ------------------------ Populate individual Elements in the form
// var firstNameField = form.items.get(0).items.get(0);
// firstNameField.setValue('Manish');

// ------------------------ Populate entire form
// var data = {
//     FirstName: 'Manish',
//     LastName: 'Sharma',
//     EmailAddress: 'manishvbn@gmail.com',
//     TelNumberCode: '91',
//     TelNumber: '9822025942',
//     RequestDetails: 'This is some Request',
//     RequestType: {
//         RequestType1: true,
//         RequestType2: false,
//         RequestType3: true,
//         RequestType4: true,
//         RequestType5: false,
//         RequestType6: true,
//     }
// };

// form.getForm().setValues(data);

// -------------------------------- Using Model
// var data = {
//     FirstName: 'Manish',
//     LastName: 'Sharma',
//     EmailAddress: 'manishvbn@gmail.com',
//     TelNumberCode: '91',
//     TelNumber: '9822025942',
//     RequestDetails: 'This is some Request',
//     RequestType: {
//         RequestType1: true,
//         RequestType2: false,
//         RequestType3: true,
//         RequestType4: true,
//         RequestType5: false,
//         RequestType6: true,
//     }
// };

// Ext.define('Request', {
//     extend: 'Ext.data.Model',
//     fields: [
//         "FirstName",
//         "LastName",
//         "EmailAddress",
//         "TelNumberCode",
//         "TelNumber",
//         "RequestDetails",
//         "RequestType"
//     ]
// });

// var requestModel = Ext.create("Request", data);
// form.getForm().loadRecord(requestModel);

Ext.define('Request', {
    extend: 'Ext.data.Model',
    fields: [
        "FirstName",
        "LastName",
        "EmailAddress",
        "TelNumberCode",
        "TelNumber",
        "RequestDetails",
        "RequestType"
    ]
});

form.getForm().load({
    url: 'formData.json'
});
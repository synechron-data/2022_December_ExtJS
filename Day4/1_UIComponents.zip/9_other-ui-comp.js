// var checkboxGroup = new Ext.form.CheckboxGroup({
//     columns: 2,
//     fieldLabel: 'Technologies',
//     name: 'technologies',
//     style: {
//         padding: '5px 10px 5px 10px'
//     },
//     items: [{
//         xtype: 'checkbox',
//         boxLabel: 'JavaScript',
//         name: 'technologies',
//         inputValue: 'javascript'
//     }, {
//         xtype: 'checkbox',
//         boxLabel: 'C#',
//         name: 'technologies',
//         inputValue: 'c#'
//     }, {
//         xtype: 'checkbox',
//         boxLabel: 'HTML',
//         name: 'technologies',
//         inputValue: 'html'
//     }, {
//         xtype: 'checkbox',
//         boxLabel: 'SQL',
//         name: 'technologies',
//         inputValue: 'sql'
//     }, {
//         xtype: 'checkbox',
//         boxLabel: 'Python',
//         name: 'technologies',
//         inputValue: 'python'
//     }, {
//         xtype: 'checkbox',
//         boxLabel: 'CSS',
//         name: 'technologies',
//         inputValue: 'css'
//     }]
// });

// var formPanel = new Ext.form.Panel({
//     renderTo: Ext.getBody(),

//     title: 'Technologies',
//     tbar: [{
//         text: 'Submit',
//         handler: function () {
//             console.log(formPanel.getValues());
//         }
//     }],

//     items: [checkboxGroup]
// });

// ------------------------------------------------

// var formPanel = new Ext.form.Panel({
//     renderTo: Ext.getBody(),
//     width: 300,
//     title: 'Dates',
//     items: [
//         {
//             xtype: 'datefield',
//             anchor: '100%',
//             filedLabel: "From",
//             name: 'from_date',
//             maxValue: new Date()
//         },
//         {
//             xtype: 'datefield',
//             anchor: '100%',
//             filedLabel: "To",
//             name: 'to_date',
//             value: new Date()
//         }
//     ]
// });

// ------------------------------------------------
// Ext.tip.QuickTipManager.init();  

// Ext.create('Ext.form.HtmlEditor', {
//     width: 580,
//     height: 250,
//     renderTo: Ext.getBody()
// });

Ext.tip.QuickTipManager.init();  

new Ext.panel.Panel({
    title: 'HTML Editor',
    renderTo: Ext.getBody(),
    width: 550,
    height: 250,
    frame: true,
    layout: 'fit',
    items: {
        xtype: 'htmleditor',
        enableColors: false,
        enableAlignments: false
    }
});
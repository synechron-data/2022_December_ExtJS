Ext.define('EnhancementLog.controller.Enhancement', {
    extend: 'Ext.app.Controller',

    stores: ['Enhancement'],

    models: ['Enhancement'],

    views: ['enhancement.EnhancementGrid'],

    init: function () {
        console.log("Controller Initialized...");
    }
});
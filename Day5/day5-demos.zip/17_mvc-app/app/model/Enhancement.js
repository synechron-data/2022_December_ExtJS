Ext.define('EnhancementLog.model.Enhancement', {
    extend: 'Ext.data.Model',
    fields: ['id', 'title', 'description']
});
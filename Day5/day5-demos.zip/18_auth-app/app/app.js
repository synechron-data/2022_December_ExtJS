Ext.application({
    name: 'LoginAppDemo',

    controllers: ['Main'],

    launch: function () {
        Ext.create('LoginAppDemo.view.LoginForm');
    }
});
const url = require('url');
var express = require('express');
var cors = require('cors');

var app = express();
var total = 6000;
var status = ['Paid', 'Viewed', 'Draft', 'Partial'];

function createData(start, limit) {
    var invoices = [];
    var end = Number(start) + Number(limit);
    for (let i = start; i < end; i++) {
        var invoice = {
            id: i,
            Client: `Global Interactive Technologies (${i})`,
            Description: "Creating an Invoice management system",
            Date: new Date(new Date(2012, 0, 1).getTime() + Math.random() * (new Date(2012, 0, 1) - new Date().getTime())),
            Amount: 200,
            Currency: "GBP",
            Status: status[Math.floor(Math.random() * status.length)]
        };

        invoices.push(invoice);
    }

    return invoices;
}

app.use(cors());

app.get('/invoices*', function (req, res, next) {
    const queryObject = url.parse(req.url, true).query;
    // console.log(queryObject);
    res.json({
        success: true,
        total: total,
        invoices: createData(queryObject.start, queryObject.limit)
    });
});

app.listen(8000, function () {
    console.log('CORS-enabled web server listening on port 8000')
})